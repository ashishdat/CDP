FROM node:20-alpine AS build
WORKDIR /app
COPY apps/evaluation_ui/package*.json ./
RUN npm ci
COPY apps/evaluation_ui/ ./
RUN npm run build

FROM nginx:1.27-alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY deploy/nginx/evaluation-ui.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
