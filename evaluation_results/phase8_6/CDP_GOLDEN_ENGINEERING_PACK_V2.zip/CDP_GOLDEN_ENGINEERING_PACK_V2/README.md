# CDP Golden Engineering Pack V1

PHI-free synthetic engineering dataset for Phase 8.1 validation.

Contents:
- 50 CMS-like professional claim mock pages
- 50 UB-like institutional claim mock pages
- Clean, low-contrast, blur, noise, skew and shift variants
- field_truth.csv with expected values and approximate value boxes
- ub04_service_line_truth.csv with row/cell truth
- manifest.json with SHA256 hashes

Important:
This is engineering validation data only. It is not an official CMS-1500/UB-04 reproduction and must not be used as production holdout evidence or reported as production accuracy.

Recommended use:
1. Run truth-route extraction.
2. Measure anchor/field localization.
3. Measure expected-value-in-region.
4. Measure OCR given correct localization.
5. Measure UB row/column reconstruction.
6. Use failures to harden generic Phase 8 dynamic extraction logic.
